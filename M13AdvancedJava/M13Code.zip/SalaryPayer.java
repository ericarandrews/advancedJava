
public class SalaryPayer implements Payer {

	@Override
	public void pay() {
		System.out.println("Paying via salary");
	}
}
