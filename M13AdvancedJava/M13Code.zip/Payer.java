
public interface Payer {

	void pay();
	
}
